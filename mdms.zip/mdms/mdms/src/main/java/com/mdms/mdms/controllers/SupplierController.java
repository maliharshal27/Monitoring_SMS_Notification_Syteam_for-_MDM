package com.mdms.mdms.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/supplier")
public class SupplierController {


    @RequestMapping("/dashboard")
    public String dashboard(){

        return "supplier/dashboard";
    }

    
    

}
