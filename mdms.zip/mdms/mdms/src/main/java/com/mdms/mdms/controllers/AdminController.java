package com.mdms.mdms.controllers;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.mdms.mdms.entites.School;
import com.mdms.mdms.service.SchoolService;

@Controller
@RequestMapping("/admin")
public class AdminController {


    @Autowired
    private SchoolService schoolService;

    @GetMapping("/dashboard")
    public String dashboard(){

        return "admin/admin_dashboard";
    }


    @PostMapping("/login")
    public String login(@RequestParam String email, 
                        @RequestParam("password") String password, 
                        RedirectAttributes redirectAttributes) {


        System.out.println(email);
        System.out.println(password);
        // Validate credentials
        if ("admin@gmail.com".equals(email) && "123456".equals(password)) {
            // Successful login, redirect to the dashboard
            return "admin/admin_dashboard"; // or to wherever you want to redirect
        } else {
            // Invalid login, return an error message or redirect to the login page
            redirectAttributes.addFlashAttribute("error", "Invalid credentials!");
            return "redirect:/admin/login";  // Redirect back to login page
        }
    }



    @GetMapping("/view-schools")
    public String getAllSchools(org.springframework.ui.Model model) {
        List<School> schools = schoolService.getAllSchools();
        System.out.println("Inside view School");
        model.addAttribute("schools", schools);
        return "admin/view_schools";
    }

    @GetMapping("/school/{school_Id}")
    @ResponseBody
    public School getSchool(@PathVariable String school_Id){

        System.out.println("Searching for student ID: " + school_Id);
        School school=schoolService.getSchoolById(school_Id);
        return school;
    }
}
