package com.mdms.mdms.service.serviceImpl;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.mdms.mdms.entites.School;
import com.mdms.mdms.entites.Student;
import com.mdms.mdms.repositories.StudentRepository;
import com.mdms.mdms.service.StudentService;


@Service
public class StudentServiceImpl implements StudentService{

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Override
    public Student saveStudent(Student student) {

        final  String mdmName="STUDENT_MDM_";
        String studentId=UUID.randomUUID().toString();
        student.setStudentId(studentId);

        student.setStudent_Password(passwordEncoder.encode(student.getStudent_Password()));


        // String studentName=student.getStudentName();
        // // String schoolId=student.getSchool().getSchool_Id();
        // String schoolName=student.getSchool().getSchool_Name();
        // String studentRollNo=Integer.toString(student.getStudent_Roll_No());

        String studentMDMID=mdmName + UUID.randomUUID().toString().substring(0, 5);

        student.setStudent_mdm_id(studentMDMID);
        
        return studentRepository.save(student);
    }

    @Override
    public Student getStudentByEmail(String userName) {

        return studentRepository.findByStudentEmail(userName).orElse(null);

    }

    @Override
    public Page<Student> getByUserName(School school, int page, int size, String sortBy, String direction) {
        
        Sort sort=direction.equals("desc") 
            ? Sort.by(sortBy).descending():Sort.by(sortBy).ascending();

        // System.out.println(sort);
        var pageable=PageRequest.of(page, size,sort);
        // System.out.println(pageable);
        // Student student=(Student) studentRepository.findBySchool(school,pageable);
        Page<Student> studentsPage = studentRepository.findBySchool(school, pageable);
    
        // Log the details of the returned Page
        // System.out.println("Total Elements: " + studentsPage.getTotalElements());
        // System.out.println("Total Pages: " + studentsPage.getTotalPages());
        // System.out.println("Content: " + studentsPage.getContent());
        
        return studentsPage;


    }

    @Override
    public Page<Student> searchByName(String nameKeyword, int size, int page, String sortBy, String direction, School school) {

        Sort sort = direction.equals("desc") ? Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
        var pageable = PageRequest.of(page, size, sort);
        return studentRepository.findBySchoolAndStudentNameContaining(school, nameKeyword, pageable);
    }

    @Override
    public Page<Student> searchByEmail(String emailKeyWord, int size, int page, String sortBy, String direction, School school) {

        Sort sort = direction.equals("desc") ? Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
        var pageable = PageRequest.of(page, size, sort);
        return studentRepository.findBySchoolAndStudentEmailContaining(school, emailKeyWord, pageable);
    }

    @Override
    public Page<Student> searchByPhoneNumber(String phoneKeyWord, int size, int page, String sortBy, String direction, School school) {

        Sort sort = direction.equals("desc") ? Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
        var pageable = PageRequest.of(page, size, sort);
        return studentRepository.findBySchoolAndStudentPhoneNumberContaining(school, phoneKeyWord, pageable);
    }

    @Override
    public Student getByStudentId(String studentId) {

        return studentRepository.findById(studentId).orElse(null);
      
    }

    @Override
    public void deleteStudent(String id) {

        studentRepository.deleteById(id);
    }

    @Override
    public Student updateStudent(Student student) {

        var studentOld=studentRepository.findById(student.getStudentId()).orElseThrow(()->new UsernameNotFoundException("Student Not Found: "));

        studentOld.setStudentName(student.getStudentName());
        studentOld.setStudentEmail(student.getStudentEmail());
        studentOld.setStudent_Address(student.getStudent_Address());
        studentOld.setStudentPhoneNumber(student.getStudentPhoneNumber());
        studentOld.setStudent_Parents_Mobile_Number(student.getStudent_Parents_Mobile_Number());
        studentOld.setStudent_Age(student.getStudent_Age());
        studentOld.setStudent_Standard(student.getStudent_Standard());
        studentOld.setStudent_Height(student.getStudent_Height());
        studentOld.setStudent_Weight(student.getStudent_Weight());
        studentOld.setStudent_Roll_No(student.getStudent_Roll_No());

        return studentRepository.save(studentOld);
    }

    
}
