package com.mdms.mdms.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


import com.mdms.mdms.entites.MealRequest;
import com.mdms.mdms.service.MealRequestService;

@Controller
@RequestMapping("/school/mealRequests")
public class MealRequestController {


    @Autowired
    private MealRequestService mealRequestService;

    @PostMapping("/{schoolId}")
    @ResponseBody
    public String createMealRequest(@PathVariable String schoolId, @RequestBody MealRequest mealRequest) {
        System.out.println("createMealRequest");
        MealRequest meal= mealRequestService.createMealRequest(schoolId, mealRequest);
        System.out.println(meal);
        return "Meal Request works...";
    }
}
