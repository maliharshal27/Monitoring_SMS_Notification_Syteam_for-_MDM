package com.mdms.mdms.service;

import java.util.List;

import com.mdms.mdms.entites.Supplier;



public interface SupplierService {

    public Supplier saveSupplier(Supplier supplier);

    public List<Supplier> getAllSupplier();

}
