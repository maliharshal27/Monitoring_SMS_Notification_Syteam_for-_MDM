package com.mdms.mdms.service;

import com.mdms.mdms.entites.MealRequest;

public interface MealRequestService {

    public MealRequest createMealRequest(String schoolId, MealRequest mealRequest);

    
}
