package com.mdms.mdms.service.serviceImpl;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mdms.mdms.entites.MealRequest;
import com.mdms.mdms.entites.School;
import com.mdms.mdms.repositories.MealRequestRepository;
import com.mdms.mdms.repositories.SchoolRepository;
import com.mdms.mdms.service.MealRequestService;


@Service
public class MealRequestServiceImpl implements MealRequestService{


    @Autowired
    private MealRequestRepository mealRequestRepository;

    @Autowired
    private SchoolRepository schoolRepository;

    @Override
    public MealRequest createMealRequest(String schoolId, MealRequest mealRequest) {

        String mealId=UUID.randomUUID().toString().substring(0, 10);
        mealRequest.setMealRequestId(mealId);
        School school = schoolRepository.findById(schoolId)
                    .orElseThrow(() -> new RuntimeException("School not found"));

            mealRequest.setSchool(school); // Link the meal request to the school

            return mealRequestRepository.save(mealRequest); // Save the meal request to DB
        }

}
