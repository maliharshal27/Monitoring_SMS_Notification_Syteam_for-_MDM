package com.mdms.mdms.forms;

import lombok.Data;

@Data
public class StudentSearchForm {

    public String field;
    public String value;
}       
