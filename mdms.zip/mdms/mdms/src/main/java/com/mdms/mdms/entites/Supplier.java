package com.mdms.mdms.entites;

import java.util.Collection;
import java.util.Collections;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "supplier_table")
@Data
public class Supplier implements UserDetails{

    @Id
    private String supplierId;
    private String supplierName;
    private String supplierAddress;
    private String supplierEmail;
    private String supplierContactNumber;
    private String supplierPassword;
    private String FSSAIRegistrationNumber;
    private boolean govermentApproval;





    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return Collections.emptyList();
    }


    @Override
    public String getPassword() {
        
        return this.supplierPassword;
    }


    @Override
    public String getUsername() {
        return this.supplierEmail;
    }
}
