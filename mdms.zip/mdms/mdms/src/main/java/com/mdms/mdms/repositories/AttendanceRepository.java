package com.mdms.mdms.repositories;

import java.time.LocalDate;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mdms.mdms.entites.Attendance;

@Repository
public interface AttendanceRepository extends JpaRepository<Attendance, String>{

       // Custom query to find attendance records by student and date
    List<Attendance> findByStudent_StudentIdAndDate(String studentId,LocalDate date);
    
    // Custom query to find attendance by mealRequest
    List<Attendance> findByMealRequest_MealRequestId(String mealRequestId);
}
