package com.mdms.mdms.service.serviceImpl;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.mdms.mdms.entites.Supplier;
import com.mdms.mdms.repositories.SupplierRepository;
import com.mdms.mdms.service.SupplierService;

@Service
public class SupplierServiceImpl implements SupplierService{

    @Autowired
    private SupplierRepository supplierRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;


    @Override
    public Supplier saveSupplier(Supplier supplier) {
        
        System.out.println("SupplierServiceImpl:-->Inside saveSupplier method: ");
        String supplierId=UUID.randomUUID().toString();
        supplier.setSupplierId(supplierId);

        supplier.setSupplierPassword(passwordEncoder.encode(supplier.getPassword()));

        return supplierRepository.save(supplier);

    }


    @Override
    public List<Supplier> getAllSupplier() {
        
        return supplierRepository.findAll();
    }

}
