package com.mdms.mdms.entites;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Data;

@Entity
@Data
public class MealRequest {


    @Id
    private String mealRequestId;

    @ManyToOne
    @JoinColumn(name = "school_id")
    private School school;

    private String mealType; // e.g., "Rice, Dal, Vegetables"
    private Double quantity; // Quantity needed (e.g., 50 kg)
    private String nutritionalRequirements; // E.g., "Vegetarian, Fortified"
    private String deliveryDate; // Date the meal needs to be delivered
    private String contactPerson; // Contact person at the school
    private String contactPhone; // Contact phone of the person


       // Custom toString method
       @Override
       public String toString() {
           return "MealRequest{" +
                   "mealRequestId='" + mealRequestId + '\'' +
                   ", schoolId='" + (school != null ? school.getSchool_Id() : "N/A") + '\'' +  // Print schoolId if school is not null
                   ", mealType='" + mealType + '\'' +
                   ", quantity=" + quantity +
                   ", nutritionalRequirements='" + nutritionalRequirements + '\'' +
                   ", deliveryDate='" + deliveryDate + '\'' +
                   ", contactPerson='" + contactPerson + '\'' +
                   ", contactPhone='" + contactPhone + '\'' +
                   '}';
       }

}
