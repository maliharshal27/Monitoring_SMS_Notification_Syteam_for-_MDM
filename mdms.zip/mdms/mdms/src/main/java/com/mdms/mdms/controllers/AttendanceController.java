package com.mdms.mdms.controllers;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mdms.mdms.entites.Attendance;
import com.mdms.mdms.service.AttendanceService;

@RestController
@RequestMapping("/school/attendance")
public class AttendanceController {


    @Autowired
    private AttendanceService attendanceService;

    @PostMapping("/mark")
    public Attendance markAttendance(
            @RequestParam String studentId,
            @RequestParam String mealRequestId,
            @RequestParam Boolean attended,
            @RequestParam String date) {

        String trimmedDate = date.trim();
        LocalDate attendanceDate = LocalDate.parse(trimmedDate); // Convert the string date to LocalDate
        Attendance atd=attendanceService.markAttendance(studentId, mealRequestId, attended, attendanceDate);
        System.out.println(atd);
        return atd;

    }
}
