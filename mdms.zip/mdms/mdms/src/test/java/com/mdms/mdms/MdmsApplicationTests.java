package com.mdms.mdms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MdmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
